﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Caf.Job.Entity
{
    public class RefreshIntervalEntity
    {
        /// <summary>
        /// 间隔时间
        /// </summary>
        public int IntervalTime { get; set; }
    }
}
