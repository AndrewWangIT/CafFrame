﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Caf.Job
{
    public enum TriggerTypeEnum
    {
        None = 0,
        Cron = 1,
        Simple = 2,
    }
}
