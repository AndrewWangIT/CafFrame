﻿namespace Caf.Job
{
    public enum MailMessageEnum
    {
        None = 0,
        Err = 1,
        All = 2
    }
}
